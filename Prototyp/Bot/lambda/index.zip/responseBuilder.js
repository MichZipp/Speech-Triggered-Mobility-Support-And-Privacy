"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getNewDocAppointmet = exports.getDocs = exports.getUserLocation = exports.getUserName = void 0;

var _api = require("./api");

var error_response = "Sorry, something went wrong, please try again!";

var getUserName = function getUserName(access_token, user_id) {
  return new Promise(function (resolve, reject) {
    var response;
    (0, _api.getUserProfile)(access_token, user_id).then(function (profile) {
      response = "Are you kidding me, your name is " + profile.vorname + " " + profile.name;
      resolve(response);
    }).catch(function (error) {
      response = "Error: " + error;
      reject(response);
    });
  });
};

exports.getUserName = getUserName;

var getUserLocation = function getUserLocation(access_token, user_id) {
  return new Promise(function (resolve, reject) {
    var response;
    (0, _api.getUserProfile)(access_token, user_id).then(function (profile) {
      response = "Actually you are in " + profile.location;
      resolve(response);
    }).catch(function (error) {
      response = "Error: " + error;
      reject(response);
    });
  });
};

exports.getUserLocation = getUserLocation;

var getDocs = function getDocs(access_token, user_id) {
  return new Promise(function (resolve, reject) {
    var response = "In furtwangen are the following doctors: ",
        location,
        docsNumber = 0;
    (0, _api.getUserProfile)(access_token, user_id).then(function (profile) {
      location = profile.location;
      console.log("Location: " + profile.location);
      (0, _api.getDocIds)(access_token).then(function (ids) {
        var promises = [];

        for (var i in ids) {
          promises.push((0, _api.getUserProfile)(access_token, ids[i]));
        }

        Promise.all(promises).then(function (docs) {
          for (var i in docs) {
            if (docs[i].location === location) {
              docsNumber++;
              response += docs[i].vorname + " " + docs[i].name + ", ";
            }
          }

          if (docsNumber === 0) {
            response = "Unfortunately, no doctors were found nearby";
          }

          console.log("Response: " + response);
          resolve(response);
        }).catch(function (error) {
          console.log(error);
          reject(error);
        });
      }).catch(function (error) {
        console.log(error);
        reject(error);
      });
    }).catch(function (error) {
      response = "Error: " + error;
      reject(response);
    });
  });
};

exports.getDocs = getDocs;

var getNewDocAppointmet = function getNewDocAppointmet(access_token, user_id) {
  return new Promise(function (resolve, reject) {
    var docs = [];
    var response = "In furtwangen are the following doctors: ";
    (0, _api.getDocIds)(access_token, user_id).then(function (ids) {
      var promises = [];

      for (var i in ids) {
        promises.push((0, _api.getUserProfile)(access_token, ids[i]));
      }

      Promise.all(promises).then(function (docs) {
        for (var i in docs) {
          response += docs[i].vorname + " " + docs[i].name + ", ";
        }

        console.log("Response: " + response);
        resolve(response);
      }).catch(function (error) {
        console.log(error);
        reject(error);
      });
    }).catch(function (error) {
      console.log(error);
      reject(error);
    });
  });
};

exports.getNewDocAppointmet = getNewDocAppointmet;