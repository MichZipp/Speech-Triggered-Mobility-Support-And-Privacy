"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getNewDocAppointmet = exports.getDocs = exports.getUserLocation = exports.getUserName = void 0;

var _api = require("./api");

var _helpers = require("./helpers");

var error_response = "Sorry, something went wrong, please try again!";
var weekdays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];
var times = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

var getUserName = function getUserName(access_token, user_id) {
  return new Promise(function (resolve, reject) {
    var response;
    (0, _api.getUserProfile)(access_token, user_id).then(function (profile) {
      response = "Are you kidding me, your name is " + profile.vorname + " " + profile.name;
      resolve(response);
    }).catch(function (error) {
      response = "Error: " + error;
      reject(response);
    });
  });
};

exports.getUserName = getUserName;

var getUserLocation = function getUserLocation(access_token, user_id) {
  return new Promise(function (resolve, reject) {
    var response;
    (0, _api.getUserProfile)(access_token, user_id).then(function (profile) {
      response = "Actually you are in " + profile.location;
      resolve(response);
    }).catch(function (error) {
      response = "Error: " + error;
      reject(response);
    });
  });
};

exports.getUserLocation = getUserLocation;

var getDocs = function getDocs(access_token, user_id) {
  return new Promise(function (resolve, reject) {
    var response = "In furtwangen are the following doctors: ",
        location,
        docsNumber = 0;
    (0, _api.getUserProfile)(access_token, user_id).then(function (profile) {
      location = profile.location;
      console.log("Location: " + profile.location);
      (0, _api.getDocIds)(access_token).then(function (ids) {
        var promises = [];

        for (var i in ids) {
          promises.push((0, _api.getUserProfile)(access_token, ids[i]));
        }

        Promise.all(promises).then(function (docs) {
          for (var i in docs) {
            if (docs[i].location === location) {
              docsNumber++;
              response += docs[i].vorname + " " + docs[i].name + ", ";
            }
          }

          if (docsNumber === 0) {
            response = "Unfortunately, no doctors were found nearby";
          }

          console.log("Response: " + response);
          resolve(response);
        }).catch(function (error) {
          console.log(error);
          reject(error);
        });
      }).catch(function (error) {
        console.log(error);
        reject(error);
      });
    }).catch(function (error) {
      response = "Error: " + error;
      reject(response);
    });
  });
};

exports.getDocs = getDocs;

var getNewDocAppointmet = function getNewDocAppointmet(access_token, user_id, callback, sessionAttributes) {
  return new Promise(function (resolve, reject) {
    var response = "In furtwangen are the following doctors: ",
        location,
        docsNumber = 0,
        docNames = [];
    (0, _api.getUserProfile)(access_token, user_id).then(function (profile) {
      location = profile.location;
      console.log("Location: " + profile.location);
      (0, _api.getDocIds)(access_token).then(function (ids) {
        var promises = [];

        for (var i in ids) {
          promises.push((0, _api.getUserProfile)(access_token, ids[i]));
        }

        Promise.all(promises).then(function (docs) {
          for (var i in docs) {
            if (docs[i].location === location) {
              docsNumber++;
              docNames.push(docs[i].vorname + " " + docs[i].name + ", ");
            }
          }

          if (docsNumber === 0) {
            response = "Unfortunately, no doctors were found nearby";
          } else {
            var randomDocNumber = getRandomInt(0, docNames.length - 1);
            var randomDayNumber = getRandomInt(0, weekdays.length - 1);
            var randomTimeNumber = getRandomInt(0, times.length - 1);
            response = "I found an appointment to see " + docNames[randomDocNumber] + " next " + weekdays[randomDayNumber] + " at " + times[randomTimeNumber] + " o'clock! As well i reservated a2 car for you at HFU e-carsharing! You can pick up the car 30 minutes before your appointment!";
          }

          console.log("Response: " + response);
          callback((0, _helpers.close)(sessionAttributes, response));
        }).catch(function (error) {
          console.log(error);
          reject(error);
        });
      }).catch(function (error) {
        console.log(error);
        reject(error);
      });
    }).catch(function (error) {
      response = "Error: " + error;
      reject(response);
    });
  });
};

exports.getNewDocAppointmet = getNewDocAppointmet;

var getRandomInt = function getRandomInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
};