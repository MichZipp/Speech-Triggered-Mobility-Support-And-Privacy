"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getUserLocation = exports.getUserName = void 0;

var _api = require("./api");

var error_response = "Sorry, something went wrong, please try again!";

var getUserName = function getUserName(access_token, user_id) {
  return new Promise(function (resolve, reject) {
    var response;
    (0, _api.getUserProfile)(access_token, user_id).then(function (profile) {
      console.log("Response:" + profile);
      response = "Are you kiddinng me, your name is: " + profile.vorname + " " + profile.name;
      resolve(response);
    }).catch(function (error) {
      response = "Error: " + error;
      reject(response);
    });
  });
};

exports.getUserName = getUserName;

var getUserLocation = function getUserLocation(access_token, profile_id) {
  return new Promise(function (resolve, reject) {
    try {
      var profile = (0, _api.getUserProfile)(access_token, profile_id);
      var response = "Actually you are in " + profile.location;
      resolve(response);
    } catch (error) {
      reject(error_response);
    }
  });
};

exports.getUserLocation = getUserLocation;