"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getDocs = exports.getUserLocation = exports.getUserName = void 0;

var _api = require("./api");

var error_response = "Sorry, something went wrong, please try again!";

var getUserName = function getUserName(access_token, user_id) {
  return new Promise(function (resolve, reject) {
    var response;
    (0, _api.getUserProfile)(access_token, user_id).then(function (profile) {
      response = "Are you kidding me, your name is " + profile.vorname + " " + profile.name;
      resolve(response);
    }).catch(function (error) {
      response = "Error: " + error;
      reject(response);
    });
  });
};

exports.getUserName = getUserName;

var getUserLocation = function getUserLocation(access_token, user_id) {
  return new Promise(function (resolve, reject) {
    var response;
    (0, _api.getUserProfile)(access_token, user_id).then(function (profile) {
      response = "Actually you are in " + profile.location;
      resolve(response);
    }).catch(function (error) {
      response = "Error: " + error;
      reject(response);
    });
  });
};

exports.getUserLocation = getUserLocation;

var getDocs = function getDocs(access_token, user_id) {
  return new Promise(function (resolve, reject) {
    var response;
    (0, _api.getDocIds)(access_token, user_id).then(function (profile) {
      response = "Actually you are in " + profile.location;
      resolve(response);
    }).catch(function (error) {
      response = "Error: " + error;
      reject(response);
    });
  });
};

exports.getDocs = getDocs;