"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getDocs = exports.getUserProfileLocation = exports.getUserProfileName = exports.getUserName = void 0;

var _nodeFetch = _interopRequireDefault(require("node-fetch"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var access_token = "PhNcTP7GpCaPoXW2EqylcgbISnyT98YEMBAXNebJW3cFto9HlXBJgYye9zV9WYn7";
var url = "http://192.52.33.31:3000/api/profiles?access_token=";

var getUserName = function getUserName() {
  return new Promise(function (resolve, reject) {
    (0, _nodeFetch.default)(url.concat(access_token)).then(function (data) {
      console.log(data);
      var user = data.json();
      var username = user.firstname + " " + lastname;
      resolve(username);
    }).catch(function (error) {
      reject(error);
    });
  });
};

exports.getUserName = getUserName;

var getUserProfileName = function getUserProfileName() {
  return new Promise(function (resolve, reject) {
    (0, _nodeFetch.default)(url.concat(access_token)).then(function (data) {
      var user = data.json();
      var profile = user.profileName;
      resolve(profile);
    }).catch(function (error) {
      reject(error);
    });
  });
};

exports.getUserProfileName = getUserProfileName;

var getUserProfileLocation = function getUserProfileLocation() {
  return new Promise(function (resolve, reject) {
    (0, _nodeFetch.default)(url.concat(access_token)).then(function (data) {
      var user = data.json();
      var location = user.location;
      resolve(location);
    }).catch(function (error) {
      reject(error);
    });
  });
};

exports.getUserProfileLocation = getUserProfileLocation;

var getDocs = function getDocs() {
  /* return new Promise(function(resolve, reject) {
      fetch(url.concat(access_token))
      .then( data => {
          var user = data.json();
          var profile = user.profileName;
          resolve(profile);
      })
      .catch( error => {
          reject(error);
      });
  });  */
  return "In Furtwangen you can find doc furti and doc else!";
};

exports.getDocs = getDocs;