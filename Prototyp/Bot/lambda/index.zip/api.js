"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getDocIds = exports.getUserProfile = void 0;

var _nodeFetch = _interopRequireDefault(require("node-fetch"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var api_url = "http://192.52.32.250:3000/api/customers/";
var res_access_token = "/profiles?access_token=";
var res_docs = "http://192.52.32.250:3000/api/customers?filter=%7B%22where%22%3A%20%7B%22Usertype%22%3A%201%7D%7D&access_token=";
/**
 * Returns the profile of the user
 */

var getUserProfile = function getUserProfile(access_token, user_id) {
  return new Promise(function (resolve, reject) {
    var url = api_url.concat(user_id).concat(res_access_token).concat(access_token);
    console.log(url);
    (0, _nodeFetch.default)(url).then(function (data) {
      return data.json();
    }).then(function (json) {
      resolve(json[0]);
    }).catch(function (error) {
      reject(error);
    });
  });
};
/**
 * Returns all profiles of docs
 */


exports.getUserProfile = getUserProfile;

var getDocIds = function getDocIds(access_token) {
  return new Promise(function (resolve, reject) {
    var url = res_docs.concat(access_token);
    console.log("url: " + url);
    (0, _nodeFetch.default)(url).then(function (data) {
      return data.json();
    }).then(function (json) {
      console.log(JSON.stringify(json));

      for (var i in json) {
        console.log("Doc: " + JSON.stringify(json[i]));
      }

      resolve(json);
    }).catch(function (error) {
      reject(error);
    });
  });
};

exports.getDocIds = getDocIds;