"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getUserProfileName = exports.getUserName = void 0;
var access_token = "PhNcTP7GpCaPoXW2EqylcgbISnyT98YEMBAXNebJW3cFto9HlXBJgYye9zV9WYn7";
var url = "http://192.52.33.31:3000/api/profiles?access_token=";

var getUserName = function getUserName() {
  return new Promise(function (resolve, reject) {
    fetch(urt.concat(access_token)).then(function (data) {
      console.log(data);
      var user = data.json();
      var username = user.firstname + " " + lastname;
      resolve(username);
    }).catch(function (error) {
      reject(error);
    });
  });
};

exports.getUserName = getUserName;

var getUserProfileName = function getUserProfileName() {
  return new Promise(function (resolve, reject) {
    fetch(urt + access_token).then(function (data) {
      var user = data.json();
      var profile = user.profileName;
      resolve(profile);
    }).catch(function (error) {
      reject(error);
    });
  });
};

exports.getUserProfileName = getUserProfileName;