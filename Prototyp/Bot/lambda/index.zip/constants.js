"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var intents = {
  NEWDOCAPPOINTMENT: "NewDocAppointment"
};
var _default = intents;
exports.default = _default;