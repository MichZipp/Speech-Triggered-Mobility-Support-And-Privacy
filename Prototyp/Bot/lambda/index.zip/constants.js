"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var intents = {
  NEWDOCAPPOINTMENT: "NewDocAppointment",
  USERNAME: "UserName",
  USERLOCATION: "UserLocation",
  USERPROFILE: "UserProfile",
  DOCS: "GetDocs"
};
var _default = intents;
exports.default = _default;